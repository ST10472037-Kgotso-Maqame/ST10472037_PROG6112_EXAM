/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.prog6112_exam_q2;
// Q2.5
/**
 *
 * @author kgots
 */
public interface IProductCalculations {
    double GetVat();
    double GetCommission();
    double GetTotal();
}
