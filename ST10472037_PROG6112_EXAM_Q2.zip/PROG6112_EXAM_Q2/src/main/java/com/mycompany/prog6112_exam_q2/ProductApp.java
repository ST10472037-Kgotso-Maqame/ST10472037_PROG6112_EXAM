/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog6112_exam_q2;
// Q2.1
/**
 *
 * @author kgots
 */
import javax.swing.*;
import java.awt.GridLayout;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class ProductApp extends JFrame {

    private JTextField txtCustomer = new JTextField();
    private JComboBox<String> cmbProduct = new JComboBox<>(
            new String[]{"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"});
    private JTextField txtPrice = new JTextField();
    private JButton btnProcess = new JButton("PROCESS");

    public ProductApp() {
        super("Product App");
        setSize(420, 260);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 2, 5, 5));

        add(new JLabel("Customer Name:"));  add(txtCustomer);
        add(new JLabel("Select Product:")); add(cmbProduct);
        add(new JLabel("Enter Price:"));    add(txtPrice);
        add(new JLabel(""));                add(btnProcess);

        BuildMenu();
        btnProcess.addActionListener(e -> ProcessSale());
    }

    // File > Exit, Tools > Process / Clear
    private void BuildMenu() {
        JMenuBar bar = new JMenuBar();
        JMenu file = new JMenu("File");
        JMenu tools = new JMenu("Tools");
        JMenuItem exit = new JMenuItem("Exit");
        JMenuItem process = new JMenuItem("Process");
        JMenuItem clear = new JMenuItem("Clear");

        exit.addActionListener(e -> System.exit(0));
        process.addActionListener(e -> ProcessSale());   // same logic as the button
        clear.addActionListener(e -> {
            txtCustomer.setText("");
            txtPrice.setText("");
            cmbProduct.setSelectedIndex(0);
        });

        file.add(exit);
        tools.add(process);
        tools.add(clear);
        bar.add(file);
        bar.add(tools);
        setJMenuBar(bar);
    }

    private void ProcessSale() {
        try {
            String customer = txtCustomer.getText();
            String product = (String) cmbProduct.getSelectedItem();
            double price = Double.parseDouble(txtPrice.getText());

            ProductCalculations calc = new ProductCalculations(price);
            String details = "Customer Name: " + customer
                    + "\nProduct: " + product
                    + "\nVAT: R " + calc.GetVat()
                    + "\nCOMMISSION: R " + calc.GetCommission()
                    + "\nTOTAL: R " + calc.GetTotal();

            JOptionPane.showMessageDialog(this, details);
            SaveToFile(details);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid price.");
        }
    }

    // Saves the same details to data.txt in the format of the sample
    private void SaveToFile(String details) {
        try (PrintWriter out = new PrintWriter(new FileWriter("data.txt"))) {
            out.println("DATA LOG");
            out.println("************");
            out.println(details);
            out.println("************");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not save data.txt");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductApp().setVisible(true));
    }
}
