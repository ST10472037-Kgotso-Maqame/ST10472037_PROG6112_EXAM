/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog6112_exam_q2;

/**
 *
 * @author kgots
 */
// Does the VAT, commission and total calculations for one sale
public class ProductCalculations implements IProductCalculations {

    private static final double VAT_RATE = 0.15;         // 15% of price
    private static final double COMMISSION_RATE = 0.05;  // 5% of price

    private double price;

    public ProductCalculations(double price) {
        this.price = price;
    }

    @Override
    public double GetVat() {
        return price * VAT_RATE;
    }

    @Override
    public double GetCommission() {
        return price * COMMISSION_RATE;
    }

    // Total = price + VAT + commission
    @Override
    public double GetTotal() {
        return price + GetVat() + GetCommission();
    }
}
