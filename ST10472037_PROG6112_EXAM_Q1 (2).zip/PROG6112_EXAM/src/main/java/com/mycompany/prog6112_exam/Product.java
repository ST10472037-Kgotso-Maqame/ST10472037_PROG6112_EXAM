/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prog6112_exam;
// Q1.2
/**
 *
 * @author kgots
 */
public class Product implements IProduct {
    private String[] productNames;   // single array: one name per product
    private int[][] sales;           // 2D array: row = product, column = month

    public Product(String[] productNames, int[][] sales) {
        this.productNames = productNames;
        this.sales = sales;
    }

    // Adds up every month for every product
    @Override
    public int GetTotalProductsSold() {
        int total = 0;
        for (int i = 0; i < sales.length; i++) {
            total += GetProductTotal(i);
        }
        return total;
    }

    // Total sold divided by the number of entries (3 products x 3 months = 9)
    @Override
    public double GetAverageProductSold() {
        int count = 0;
        for (int i = 0; i < sales.length; i++) {
            count += sales[i].length;
        }
        return (double) GetTotalProductsSold() / count;
    }

    // Finds the product with the highest total over the three months
    @Override
    public String GetMostPopularProduct() {
        int bestIndex = 0;
        for (int i = 1; i < sales.length; i++) {
            if (GetProductTotal(i) > GetProductTotal(bestIndex)) {
                bestIndex = i;
            }
        }
        return productNames[bestIndex] + " (" + GetProductTotal(bestIndex) + ")";
    }

    // Helper so the row-adding logic is only written once
    private int GetProductTotal(int productIndex) {
        int total = 0;
        for (int month = 0; month < sales[productIndex].length; month++) {
            total += sales[productIndex][month];
        }
        return total;
    }
}
