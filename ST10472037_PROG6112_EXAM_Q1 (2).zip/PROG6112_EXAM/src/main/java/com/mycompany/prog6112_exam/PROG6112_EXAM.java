/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
// Q1.1
package com.mycompany.prog6112_exam;
import java.util.Scanner;
/*
 *
 * @author kgots
 */
public class PROG6112_EXAM {

    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);

        String[] productNames = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        int[][] sales = new int[productNames.length][3];

        // Loop through each product and each month to capture the sales
        for (int p = 0; p < productNames.length; p++) {
            for (int m = 0; m < 3; m++) {
                System.out.print("Enter number of sales for month " + (m + 1)
                        + " for " + productNames[p] + " mattress: ");
                sales[p][m] = input.nextInt();
            }
            System.out.println();
        }

        Product product = new Product(productNames, sales);
        PrintProduct printer = new PrintProduct();

        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println("***************");
        printer.PrintTotalProductSales(product);
        printer.PrintAverageProductSales(product);
        printer.PrintMostPopularProduct(product);
        input.close();
    }
    
}
